# MM21 Video Categorization (Downstream Task)

## MM21-Cls_category_index.txt
Each line in this file contains a label.

## MM21-Cls_trainval.csv (for video downloading from YouTube)
Each line in this file contains a video youtube_id, the start and end time of the video clip (second), the label index and the split (training or validation split). 

The label index corresponds to the index in `MM21-Cls_category_index.txt`.

You could use the youtube_id to download video clip from YouTube. 
