# MM21 Pre-train Video Data (Pre-training)

## MM21-Pretrain_query_index.txt
Each line in this file contains a query.

## MM21-Pretrain_video_id.txt
Each line in this file contains a video youtube_id.

## MM21-Pretrain_video_title.txt
Each line in this file contains a title of the video, whose position of line is the same with that in `MM21-Pretrain_video_id.txt`.

## MM21-Pretrain_video.csv (for video downloading from YouTube)
Each line in this file contains a video youtube_id, the start and end time of the video clip (second) and the query index. 

The query index corresponds to the index in `MM21-Pretrain_query_index.txt`.

You could use the youtube_id to download video clip from YouTube. 

