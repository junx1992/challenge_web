import os
import json as js
import pandas as pd


def load_json_evaluate(input):
    # load test groundtruth
    vname_label = {}
    df_test = pd.read_csv('cls_test_gt_list.csv',sep=' ')
    vname = df_test['video_id']
    gt = df_test['label']
    assert len(vname) == len(gt)
    vname_gt = dict(zip(vname,gt))
    # load json
    correct = 0 
    with open(input,'r') as fr:
        pred = js.load(fr)
        version, result = pred['version'], pred['result']
        assert version == 'VERSION 1.3', 'version should be 1.3.'
        assert len(result) == len(vname), 'video prediction number should be 16554.'
        for v in result:
            vname = v['video_id']
            label = v['category_id']
            gt = vname_gt[vname]
            if label == gt: correct += 1
    accuracy = correct / len(result)
    print('top-1: %f'%accuracy)
    return accuracy


def main():
    load_json_evaluate('mmds_pred_random.json')


if __name__ == '__main__':
    main()